package com.cyx.service;

import cn.hutool.core.util.ObjectUtil;
import com.cyx.common.RoleEnum;
import com.cyx.entity.Account;
import com.cyx.entity.Admin;
import com.cyx.exception.CustomException;
import com.cyx.mapper.AdminMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Title: AdminServiceImpl
 * @Author 曦
 * @Date 2025/6/3 19:55
 * @description:
 */
@Service
public class AdminServiceImpl implements AdminService{

    @Autowired
    private AdminMapper adminMapper;
    @Override
    public Account login(Account account) {
        String username = account.getUsername();
        //根据账号查询数据
        Admin dbAdmin = adminMapper.selectByUsername(username);
        if(dbAdmin == null){
            throw new CustomException("账号不存在");
        }
        //校验密码
        if(!dbAdmin.getPassword().equals(account.getPassword())){
            throw new CustomException("账号或者密码错误");
        }
        return dbAdmin;//dbAdmin是Account的子类型，可以作为返回值
    }

    @Override
    public void add(Admin admin) {
        Admin dbAdmin = adminMapper.selectByUsername(admin.getUsername());
        if(dbAdmin != null){
            throw new CustomException("账号已存在");
        }
        if(ObjectUtil.isEmpty(admin.getPassword())){
            admin.setPassword("admin");//默认密码
        }
        if(ObjectUtil.isEmpty(admin.getName())){
            admin.setName(admin.getUsername());//设置用户名称为账号名称
        }
        admin.setRole(RoleEnum.ADMIN.name());
        adminMapper.insert(admin);
    }

    @Override
    public void deleteById(Integer id) {
        adminMapper.deleteById(id);
    }

    @Override
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            this.deleteById(id);
        }
    }

    @Override
    public void updateById(Admin admin) {
        adminMapper.updateById(admin);
    }

    @Override
    public Admin selectById(Integer id) {
        return adminMapper.selectById(id);
    }

    @Override
    public List<Admin> selectAll(String name) {
        return adminMapper.selectAll(name);
    }


    @Override
    public PageInfo<Admin> selectPage(String name,Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Admin> list = this.selectAll(name);
        return PageInfo.of(list);
    }
}
