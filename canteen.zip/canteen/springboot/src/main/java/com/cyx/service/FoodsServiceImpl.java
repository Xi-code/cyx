package com.cyx.service;

import com.cyx.entity.Foods;
import com.cyx.exception.CustomException;
import com.cyx.mapper.FoodsMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;

/**
 * @Title: FoodsServiceImpl
 * @Author 曦
 * @Date 2025/6/5 18:05
 * @description:
 */
@Service
public class FoodsServiceImpl implements FoodsService{

    @Autowired
    private FoodsMapper foodsMapper;

    @Override
    public void add(Foods foods) {
        foodsMapper.insert(foods);
    }

    @Override
    public void deleteById(Integer id) {
        foodsMapper.deleteById(id);
    }

    @Override
    public void deleteBatch(List<Integer> ids) {
        for (Integer id : ids) {
            this.deleteById(id);
        }
    }

    @Override
    public void updateById(Foods foods) {
        foodsMapper.updateById(foods);
    }

    @Override
    public Foods selectById(Integer id) {
        return foodsMapper.selectById(id);
    }

    @Override
    public List<Foods> selectAll(String name) {
        return foodsMapper.selectAll(name);
    }


    @Override
    public PageInfo<Foods> selectPage(String name, BigDecimal minPrice, BigDecimal maxPrice, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum, pageSize);
        List<Foods> list = foodsMapper.selectByCondition(name, minPrice, maxPrice);
        return PageInfo.of(list);
    }


}
