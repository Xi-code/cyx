package com.cyx.common;

/**
 * @Title: RoleEnum
 * @Author 曦
 * @Date 2025/6/3 21:41
 * @description:
 */
public enum RoleEnum {
    ADMIN,
    USER
}
