package com.example.mapper;

public interface AdminMapper {


}
